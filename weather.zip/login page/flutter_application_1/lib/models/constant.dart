
import 'package:flutter/material.dart';

class Constants{
  final Color primaryColor = const Color(0xff90B2F9);
  final Color secondaryColor = const Color(0xff90B2F8);
}